# springboot-microservices-project
Project Details :-  This project is designed to take care of following services.
1. Product service :- This service will have capability to add product and search product.
2. Order Service :- This service will book the order for a product on basis of its availability. 
This service will interact with Inventory service to check if the product is in stcok
3. Inventory Service : This service will check the stock and will return boolean value based on availability of the product.
4. Notification Service : This service will trigger the email once the order is placed successfully.



