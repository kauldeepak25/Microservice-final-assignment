package com.tcs.learning.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.learning.model.Inventory;
import com.tcs.learning.repository.InventoryRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
@Slf4j
public class InventoryRestController {
	@Autowired
	private InventoryRepository inventoryRepository;

	@GetMapping("/{skuCode}")
	Boolean isInStock(@PathVariable String skuCode) {
		log.info("Checking stock for product with skucode - " + skuCode);
		Inventory inventory = inventoryRepository.findBySkuCode(skuCode)
				.orElseThrow(() -> new RuntimeException("Cannot Find Product by sku code " + skuCode));
		return inventory.getStock() > 0;
	}
}
