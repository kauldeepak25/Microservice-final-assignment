package com.tcs.learning.orderservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tcs.learning.orderservice.model.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {
}
